const roomLa = document.querySelectorAll('.roomLabel');
roomLa.forEach(function(label){
    label.addEventListener('click', link);
});

function link(event){
  window.location.href="../Game/game.html";
}